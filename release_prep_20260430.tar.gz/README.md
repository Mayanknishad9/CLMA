# 🔁 CLMA — Closed-Loop Multi-Agent Framework

> **让 AI 生成的代码自带验证、自动收敛、不再需要人工擦屁股。**

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue)](https://python.org)
[![C++17](https://img.shields.io/badge/C%2B%2B-17-green)](https://isocpp.org)
[![Build](https://img.shields.io/badge/build-CMake%203.15%2B-orange)](https://cmake.org)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

---

## 📋 目录

- [为什么需要这个框架](#-为什么需要这个框架)
- [核心架构](#-核心架构)
- [三种执行模式](#-三种执行模式)
- [效果对比](#-效果对比)
- [快速开始](#-快速开始)
- [配置 API 提供商](#-配置-api-提供商)
- [项目结构](#-项目结构)
- [Web UI 使用指南](#-web-ui-使用指南)
- [命令行使用](#-命令行使用)
- [开发指南](#-开发指南)
- [FAQ](#-faq)

---

## 🎯 为什么需要这个框架

你用过 ChatGPT / Copilot / Claude Code 写代码对吧？

第一版看起来不错 —— 跑起来全是 bug。你复制错误回去让它改 —— 它改出新的 bug。你再复制 —— 它又改。**陷入了人工反馈的死循环。**

**CLMA 把"人盯着 AI 改 bug → 告诉 AI → AI 再改"这个循环，内建到框架里。**

输入一个需求，系统自动执行：

```
需求输入
  ↓
🔍 Refiner    — 精炼模糊需求，提取约束条件
  ↓
🧠 Reasoner   — 推理解题步骤、边界条件、算法选型
  ↓
💻 Solver     — 生成代码实现
  ↓
✅ Verifier   — 自动执行代码 + 规则检查 + 多维度验证
  ↓
📊 Evaluator  — 三维度评分（合理性 / 可执行性 / 满意度）
  ↓
未达标 ←── 🔄 评分反馈，自动进入下一轮迭代
  ↓
达标 →  ✅ 输出最终结果
```

**不需要你逐轮提示、不需要你复制粘贴错误、不需要你当人工验证器。**

---

## 🧩 核心架构

```
┌───────────────────────────────────────────────────────┐
│                    Web UI (Flask)                      │
│   暗色主题 · 实时流程图 · SSE 流式输出 · 评分仪表盘    │
│   拖拽缩放 · 三层架构切换 · 会话历史 · LLM 目录       │
└──────────────┬────────────────────────────────────────┘
               │ HTTP/SSE
┌──────────────▼────────────────────────────────────────┐
│             Python 接口层 (pybind11)                   │
│    配置管理 · API 适配器 · 工具执行器 · 会话存储       │
│    评分引擎 · 迭代控制器 · 查询分类 · 经验库           │
└──────────────┬────────────────────────────────────────┘
               │ pybind11 C++ 绑定
┌──────────────▼────────────────────────────────────────┐
│               C++17 核心引擎                           │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│  │Orchestra- │ │Rule      │ │Token     │ │Loop      │ │
│  │tor       │ │Engine    │ │Monitor   │ │Controller│ │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐              │
│  │Plugin    │ │DAG       │ │Sandbox   │              │
│  │Manager   │ │Processor │ │(隔离执行) │              │
│  └──────────┘ └──────────┘ └──────────┘              │
└───────────────────────────────────────────────────────┘
```

### 核心模块

| 模块 | 技术栈 | 职责 |
|------|--------|------|
| **Orchestrator** | C++17 | 主调度器，编排 Agent 执行和迭代流程 |
| **DAG Processor** | C++17 | 有向无环图任务分解 + 并行下发 |
| **RuleEngine** | C++17 + YAML | 正则/关键词规则匹配，配置验证方法 |
| **TokenMonitor** | C++17 | Token 消耗追踪 + 预算预警 |
| **LoopController** | C++17 | 迭代次数控制 + 收敛判停 |
| **PluginManager** | C++17 | .so 插件动态热加载 |
| **Sandbox** | Python + subprocess | 隔离环境代码执行 |
| **Framework** | Python | Agent 提示词管理、评分流水线、上下文维护 |

### 5 个 Agent 角色

| Agent | 输入 | 输出 | 插件化 |
|-------|------|------|--------|
| **Refiner** 🔍 | 用户原始需求 | 精炼后的结构化任务描述 | ✅ |
| **Reasoner** 🧠 | 精炼后的查询 | 解题步骤 + 算法选型 + 边界条件 | ✅ |
| **Solver** 💻 | 推理结果 + 执行反馈 | 代码实现（Python/Bash/C++/JS/Go...） | ✅ |
| **Verifier** ✅ | 代码 + 执行结果 | JSON 格式：hard_checks + soft_checks + verdict | ✅ |
| **Evaluator** 📊 | 验证结果 + 执行输出 | JSON 格式：三维度评分 + SCORE_META 标签 | ✅ |

---

## 🔄 三种执行模式

CLMA 根据任务复杂度自适应选择执行策略：

```
query 进入
  │
  ├── 简单（"打印 Hello World" / "计算 1+1"）
  │     └── 🚀 DAG 快速通道 ~2s
  │              一步 solver → 自动执行 → 基于执行结果评分
  │
  ├── 中等（"写个斐波那契函数" / "实现二分查找"）
  │     └── 🔄 单闭环 ~5s
  │              Refiner → Reasoner → Solver → Verifier → Evaluator ← 评分反馈
  │
  └── 复杂（"设计微服务架构含 API 网关、服务发现、熔断机制"）
        └── 🔁 嵌套闭环 ~40s
               ┌─ 外环: Strategy Refiner → Strategy Reasoner
               │           ↓
               │      内环: [Solver → Verifier → Evaluator] (执行收敛)
               │           ↓
               │      Outer Verifier → Outer Evaluator (策略对齐度评估)
               └── 外环评分未达标 → 反馈修正策略 → 重新执行内环
```

### 快速通道（DAG Fast Path）

极简单任务自动跳过完整 pipeline 的 planner 开销：

```python
# 触发条件：长度 ≤ 60 字符 + 代码关键词匹配
# 不触发：算法词（排序、搜索、递归等）
"打印 1 到 100"           → 快速通道 ✓
"用 Python 写斐波那契"     → 快速通道 ✗（含"斐波那契"）
```

### DAG 模式（C++ 任务分解）

复杂多组件任务通过 C++ DAG Processor 分解为并行子任务，每个子任务独立走闭环验证，最后聚合结果。

### 嵌套闭环（Multi-Loop）

- **外环（Strategy Loop）**：定义策略、验证策略对齐度
- **内环（Execution Loop）**：执行代码、验证代码、评估质量
- **收敛判停**：评分 ≥ 阈值时自动退出，无需跑满迭代次数

---

## 📊 效果对比

以下数据基于 **DeepSeek API**（单次 LLM 调用延迟约 5-8s）：

| 任务 | 快速通道 | 单闭环 | DAG | 嵌套闭环 |
|------|----------|--------|-----|---------|
| Hello World | **2.3s** / 0.97 | 4.7s / 0.99 | 5.3s / 0.99 | — |
| 斐波那契 | — | **4.7s** / 0.99 | 5.3s / 0.99 | — |
| 快速排序 | — | **5.1s** / 0.98 | — | — |
| 文件批量重命名 | — | **8.1s** / 0.98 | 12.0s / 0.97 | — |
| 微服务架构（策略型） | — | — | — | **39s** / 1.0 ✅ |
| 多组件项目 | — | — | **~25s** / 0.97 | — |

> **什么时候该用什么模式：**
> - **快速通道**：一行代码、一条命令、简单计算 → 2s 搞定
> - **单闭环**：单个函数、一个文件、明确需求 → 5s 最优
> - **DAG**：多个独立模块、并行工作 → 各模块独立验证
> - **嵌套闭环**：复杂架构、策略约束多、需要顶层规划 → 唯一可行的方案

---

## 🚀 快速开始

### 系统要求

```bash
# 必需的
gcc/g++ 9+ 或 clang 12+
cmake 3.15+
python 3.10+
yaml-cpp      # Ubuntu: apt install libyaml-cpp-dev
sqlite3       # 通常已预装
pybind11      # pip install pybind11

# 可选的
docker        # 容器化代码执行
```

### 一步启动（推荐）

```bash
git clone https://github.com/yourname/clma.git
cd clma

# 1. 创建虚拟环境
python3 -m venv venv
source venv/bin/activate
pip install flask flask-cors pybind11

# 2. 构建 C++ 核心
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)
cd ..

# 3. 配置 API（编辑 config/api_config.json，填入你的 key）
#   详见下方 "配置 API 提供商"

# 4. 启动 Web UI
./run_webui.sh
# → 浏览器打开 http://localhost:5000
```

### 分步构建

**构建 C++ 核心引擎：**

```bash
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j$(nproc)

# 运行 C++ 单元测试（62 个测试用例）
ctest -j$(nproc)
```

**构建 Python 绑定 + Web UI：**

```bash
pip install flask flask-cors pybind11

cd build
cmake .. -DBUILD_PYTHON_BINDINGS=ON
make -j$(nproc) clma_core
# 生成的 .so 文件会自动复制到 python_interface/ 目录

cd ..
./run_webui.sh
```

**运行 Python 测试（验证所有逻辑正确）：**

```bash
source venv/bin/activate
cd tests && python3 -m pytest test_core_python.py -v

# 期望输出: 46 passed
```

---

## 🔑 配置 API 提供商

CLMA 支持 5 大 LLM 提供商，通过统一的适配器模式接入。

### 方法一：直接编辑配置文件

编辑 `config/api_config.json`：

```json
{
  "provider": "openai",
  "api_key": "sk-xxxxxxxxxxxxxxxx",
  "base_url": "https://api.openai.com/v1",
  "model": "gpt-4o",
  "max_tokens": 8192,
  "temperature": 0.7,
  "enabled": true
}
```

### 方法二：通过 Web UI 配置

打开 `http://localhost:5000` → 右上角 API 配置按钮 → 选择提供商 → 填入 API Key → 测试连接。

### 支持的提供商

| 提供商 | 配置值（provider） | 默认模型 | 特点 |
|--------|-------------------|---------|------|
| **OpenAI** | `openai` | gpt-4o | 通用最强 |
| **Anthropic** | `anthropic` | claude-sonnet-4 | 代码理解 |
| **DeepSeek** | `deepseek` | deepseek-chat | 性价比高 |
| **Gemini** | `gemini` | gemini-2.0-flash | 免费额度 |
| **Local** | `local` | 自定义 | Ollama/vLLM 兼容 |

**配置文件路径：** `config/api_config.json`
**LLM 目录（自动更新）：** `config/llm_catalog.json`

> 💡 CLMA 内置 LLM 目录自动更新脚本（`scripts/auto_update_providers.py`），每 72 小时从各提供商官网同步最新模型列表。

---

## 📁 项目结构

```
clma/
├── src/                    # C++ 核心引擎
│   ├── core/               # 核心模块实现
│   │   ├── Orchestrator.cpp    # 主调度器
│   │   ├── RuleEngine.cpp      # 规则引擎
│   │   ├── TokenMonitor.cpp    # Token 监控
│   │   ├── LoopController.cpp  # 循环控制
│   │   ├── PluginManager.cpp   # 插件管理器
│   │   ├── PluginWatcher.cpp   # 文件热监听
│   │   ├── Sandbox.cpp         # 沙箱执行
│   │   └── Types.cpp           # 类型定义
│   ├── agents/             # 插件化 Agent 接口
│   └── main.cpp            # CLI 入口（可选）
├── include/core/           # C++ 头文件
├── plugins/                # Agent 插件 (.so)
│   ├── agent_refiner/
│   ├── agent_reasoner/
│   ├── agent_solver/
│   ├── agent_verifier/
│   └── agent_evaluator/
├── python_interface/       # Python 接口层
│   ├── core.py             # 框架主逻辑 + Agent 提示词
│   ├── web_app.py          # Flask Web 应用
│   ├── api_providers.py    # 5 大 LLM 适配器
│   ├── tool_executor.py    # 沙箱代码执行
│   ├── experience_store.py # 经验存储/检索
│   ├── session_store.py    # 会话持久化
│   └── templates/          # HTML 模板
├── tests/                  # 测试（Google Test + pytest）
│   ├── test_core_python.py # Python 46 个单元测试
│   ├── test_*.cpp          # C++ 62 个单元测试
│   └── CMakeLists.txt
├── config/                 # 配置文件
│   ├── api_config.json     # API 提供商配置
│   ├── llm_catalog.json    # LLM 模型目录
│   ├── rules/default.yaml  # 规则定义
│   └── sessions/           # 历史会话（JSON）
├── docs/                   # 设计文档
├── run_webui.sh            # 一键启动脚本
└── CMakeLists.txt          # 顶层构建文件
```

---

## 🌐 Web UI 使用指南

### 页面功能

| 功能 | 位置 | 说明 |
|------|------|------|
| **查询输入** | 中央输入框 | 输入你的需求，按 Enter 提交 |
| **架构选择** | 顶部按钮组 | Single / DAG / Multi-Loop 三种模式 |
| **模式切换** | 设置面板 | Closed（迭代） / Open（一次通过） |
| **设置面板** | 右上角齿轮 | 迭代次数、阈值、超时、token 预算 |
| **实时流程图** | 左侧面板 | SVG 流程图，节点绿/红色实时状态 |
| **评分仪表盘** | 右侧面板 | 三个评分维度实时更新 + 仪表盘 |
| **执行时间线** | 底部 | 每个 Agent 的耗时瀑布图 |
| **会话历史** | 左侧菜单 | 历史查询记录，可回溯查看 |
| **API 配置** | 右上角 API 按钮 | 切换/测试不同 LLM 提供商 |
| **插件管理** | 插件页面 | 查看/加载/卸载 Agent 插件 |

### 设置参数说明

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `max_iterations` | 10 | 最大迭代次数（单闭环/外环收敛前最多跑多少次） |
| `threshold` | 0.3 | 评分收敛阈值（≥ 此值时自动停止迭代） |
| `execution_timeout` | 120 | 代码执行超时时间（秒） |
| `mode` | closed | closed（迭代闭环） / open（一次通过） |
| `arch_mode` | single | single / dag / multi（三选一） |

---

## 💻 命令行使用

```python
from core import CLMAFramework

fw = CLMAFramework(
    mode="closed",        # "closed" | "open"
    max_iterations=5,
    threshold=0.7,
    token_budget=10000,
)

# 单次查询（阻塞）
result = fw.process_query("用 Python 写一个快速排序")

print(f"分数: {result['score']['overall']}")
print(f"代码:\n{result['content']}")

# 流式查询（SSE 事件）
for event in fw.process_query_stream("设计一个 REST API 路由"):
    if event["event"] == "agent_start":
        print(f"🔄 {event['agent']} 开始处理...")
    elif event["event"] == "agent_complete":
        print(f"✅ {event['agent']} 完成 ({event['duration_ms']:.0f}ms)")
    elif event["event"] == "iteration":
        print(f"📊 第 {event['iteration']} 轮评分: {event['scores']['overall']}")
    elif event["event"] == "done":
        print(f"🎉 最终结果 (评分: {event['result']['score']['overall']})")
```

---

## 🧪 开发指南

### 添加新规则

编辑 `config/rules/default.yaml`：

```yaml
rules:
  - pattern: "deploy|build|run"
    validation_method: "execution"
    recommended_tools: ["docker", "shell"]
    weights:
      reasonableness: 0.3
      executability: 0.5
      satisfaction: 0.2
    threshold: 0.3
```

### 添加新 API 提供商

在 `python_interface/api_providers.py` 中注册：

```python
@register_provider("my_provider")
class MyProvider(BaseProvider):
    """My custom LLM provider."""
    
    def create_completion(self, messages, **kwargs):
        # 实现你的 API 调用逻辑
        ...
```

### 添加新 Agent 插件

```cpp
// plugins/my_agent/plugin.cpp
#include <core/PluginInterface.hpp>

class MyAgent : public AgentPlugin {
public:
    AgentResult execute(const Context& ctx) override {
        // 你的 Agent 逻辑
        return result;
    }
};

extern "C" AgentPlugin* create_plugin() {
    return new MyAgent();
}
```

### 运行全部测试

```bash
# C++ 测试
cd build && ctest -j$(nproc)

# Python 测试
source venv/bin/activate
python3 -m pytest tests/test_core_python.py -v
python3 -m pytest tests/test_dag_planner.py -v
python3 -m pytest tests/test_sandbox_tiering.py -v

# 全部 108+ 测试用例
```

---

## ❓ FAQ

**Q: CLMA 和 LangChain/CrewAI 有什么区别？**

A: LangChain 是链式调用库，CrewAI 是角色编排框架。CLMA 的核心差异在于**闭环反馈机制**——不只是让 Agent 按顺序跑，而是每次迭代都通过 Verifier + Evaluator 做质量评估，低于阈值就自动进入下一轮，直到收敛。

**Q: 嵌套闭环比单闭环慢，为什么还要用？**

A: 对简单任务（Hello World）确实慢，不应该用。嵌套闭环的价值在复杂策略型任务——外环定策略、内环执行、两环反馈对齐。就像卡车比自行车慢但能拉水泥，选对场景是关键。

**Q: 支持哪些编程语言？**

A: 代码执行层（Sandbox）支持 Python / Bash / C++，LLM Solver 本身可以生成任何语言。如果需要更多运行时语言，可以通过 ToolExecutor 扩展。

**Q: API Key 安全吗？**

A: API Key 存储在本地 `config/api_config.json`。框架不做任何网络外传，所有 LLM 调用直接发到对应提供商。

**Q: 支持本地模型吗？**

A: 支持。配置 `provider: "local"`，base_url 指向你的 Ollama/vLLM 端点即可。完全离线运行。

**Q: 没有 API Key 能试用吗？**

A: 可以。框架自带**模拟模式（Simulated Fallback）**——当 LLM 调用失败或无 API 配置时，自动降级为基于规则的模拟 Agent。评分能够正常演示，只是代码质量不如真实 LLM。

**Q: 古法编程是什么？**

A: 一种开发哲学——不迷信"大模型什么都能写"，坚持白盒理解、手工推演、每行代码都有确凿工程依据。CLMA 框架本身就是在古法编程指导下开发的。

---

## 📜 许可证

MIT License

---

## 🌟 支持

如果你觉得这个项目有帮助：
- ⭐ 点个 Star 让更多人看到
- 🐛 [提交 Issue](https://github.com/yourname/clma/issues) 报告 Bug
- 💡 欢迎 PR 和功能建议

---

**从"AI 写代码，人擦屁股"到"AI 写代码，自动验证"——就差一个闭环。**
